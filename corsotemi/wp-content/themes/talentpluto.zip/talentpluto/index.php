<?php get_header(); ?>




<body>


    <!-- The sidebar -->
    <div class="sidebar text-center position-fixed">
        <img src="./assets/images/cv.jpg" class="rounded-circle img-fluid m-auto d-block mt-5 py-2" width="200px">
        <a href="#home">ABOUT</a>
        <a href="#news">EXPERIENCE</a>
        <a href="#contact">EDUCATION</a>
        <a href="#about">SKILLS</a>
        <a href="#about">INTEREST</a>
        <a href="#about">AWARDS</a>
    </div>
    
    <!-- Page content -->
    <div class="content position-fixed">
        <h1>FELIPE <b>PIZARRO</b></h1>
        <h3>3542 BERRY STREET · CHEYENNE WELLS, CO 80810 · (317) 585-8468 · NAME@EMAIL.COM</h3>
        <p class="mt-4 ">I am experienced in leveraging agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate <br>strategy foster collaborative thinking to further the overall value proposition.</p>
        <div class="container  d-flex"><i class="bi bi-linkedin p-2 fs-4"></i><i class="bi bi-github p-2  fs-4"></i><i class="bi bi-twitter p-2  fs-4"></i><i class="bi bi-facebook p-2  fs-4"></i></div>
      
    </div>



<?php get_footer(); ?>