<?php

// INSERISCO IL COLLEGAMENTO CON IL CSS

function miostile() {

    wp_enqueue_style('style', get_stylesheet_uri() );

}

add_action('wp_enqueue_scripts', 'miostile');

// ATTIVO ALCUNE FUNZIONI DI WORDPRESS PER IL MIO TEMA

function miotema_theme_support() {

    add_theme_support('custom-logo');

    add_theme_support('title-tag');

    add_theme_support('custom-background');

    add_theme_support('wp-block-styles');

    add_theme_support('align-wide');

    add_theme_support('post-thumbnails');

    $location = array(
        'primary' => 'Menu Header Principale',
        'secondary' => 'Menu Footer Principale',
        'social' => 'Menu Social'
    );

    register_nav_menus($location);

}

add_action('after_setup_theme', 'miotema_theme_support');


// INSERIRE CLASSI NEL LI DEL MENU

function atg_menu_classes($classes, $item, $args) {
    if($args->theme_location == 'primary') {
      $classes[] = 'list-group-item';
    }
    return $classes;
  }
add_filter('nav_menu_css_class','atg_menu_classes',1,3);

// REGISTRIAMO NUOVI ARTICOLI PERSONALIZZATI

function mio_post_personalizzato() {

  $labels = array(
    'name' => 'IMMOBILE',
    'singular_name' => 'Immobile',
    'menu_name' => 'Immobile',
    'not_found' => 'Nessun immobile trovato',
    'all_items' => 'Tutti i immobile',
    'view_item' => 'Visualizza il immobile',
    'add_new_item' => 'Aggiungi nuovo immobile',
    'add_new' => 'Aggiungi immobile',
    'edit_item' => 'Modifica immobile',
    'update_item' => 'Aggiorna immobile',
    'search_items' => 'Cerca immobile',
    'not_found_in_trash' => 'Nessun immobile nel cestino'
  );

  $args = array(

    'labels' => $labels,
    'description' => 'Archivio di Film',
    'public' => true,
    'menu_position' => 25,
    'supports' => array('title', 'editor', 'author'),
    'has_archive' => true,
    'menu_icon'  => 'dashicons-admin-multisite',
    // 'taxonomies' => array('category','post_tag'),
    'exclude_from_search' => false,
    'publicity_queryable' => true,
    'show_in_rest' => false,
  );

  register_post_type('film', $args );

}

add_action('init','mio_post_personalizzato');