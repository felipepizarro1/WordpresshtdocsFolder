<?php include 'functions.php'?>

<?php 

echo head() ;

echo nav() ;

echo form() ;

echo footer() ;